import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { auth } from "./fireConfig";
import { onAuthStateChanged } from "firebase/auth";

function Menu() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setIsLoggedIn(!!user);
    });

    return () => unsubscribe();
  }, []);

  const logOut = () => {
    auth
      .signOut()
      .then(() => {
        console.log('Signed Out');
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
    <meta http-equiv="Content-Security-Policy" content="style-src 'self' 'unsafe-inline' https://m.stripe.network https://me.kis.v2.scr.kaspersky-labs.com wss://me.kis.v2.scr.kaspersky-labs.com"/>

      <nav className="navbar navbar-expand-lg navbar-dark" style={{ backgroundColor: '#33cccc' }}>
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            <img
              src="/images/modèle-de-conception-logo-ecommerce-avec-fond-blanc-212252837.jpg" // Replace with your logo path
              alt="Logo"
              width="30"
              height="30"
              className="d-inline-block align-top"
            />
        
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/articles">
                  List articles
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/addArticle">
                  Add articles
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/addClient">
                  Add Client
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/Client">
                  List Clients
                </Link>
              </li>
            </ul>
            {!isLoggedIn ? (
              <Link className="btn btn-outline-primary" to="/loginclient">
                Log In
              </Link>
            ) : (
              <button
                className="btn btn-outline-primary"
                onClick={() => logOut()}
              >
                Log Out
              </button>
            )}
          </div>
        </div>
      </nav>
      <div className="container">
        <header className="text-center my-4">
          <h1>Welcome to Our E-Commerce Store</h1>
          <p>Discover a wide range of products at great prices.</p>
        </header>
        <img src="/images/OIP.jpg"alt="Product 1"className="card-img-top"/>

  
      </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    </>
  );
}

export default Menu;