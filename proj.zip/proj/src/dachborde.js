import Menu from './Menu'
function Dashboard() {
    return ( <>
    <Menu/>
    </> );
}

export default Dashboard;