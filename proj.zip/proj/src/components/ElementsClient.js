import { Link } from "react-router-dom";
function ElementsClient(props) {
  return (
    <div className="container">
      <div className="row">
        {props.client &&
          props.client.map((client) => {
            return (
              <div key={client.id} className="col-sm-4">
                <div className="card" >
                  <img
                    src={client.imageartpetitf}
                    className="card-img-top"
                    alt={client.Nom}style={{ width: "15rem",height:"15rem" }}
                  />
                  <div className="card-body">
                    <h5 className="card-title">
                      {client.Prenom}
                      {client.Nom}
                    </h5>
                  </div>

                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">{client.Email} </li>
                  </ul>
                  <div className="card-body">
                    <Link
                      exact
                      to={`/editClient/${client.id}`}
                      className="btn btn-success me-2"
                    >
                      Modifier
                    </Link>

                    <button
                      onClick={() => {
                        props.deleteProd(client.id);
                      }}
                      className="btn btn-danger"
                    >
                      Supprimer
                    </button>{" "}
                  </div>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}

export default ElementsClient;