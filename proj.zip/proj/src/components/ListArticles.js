import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ElementsArticle from './ElementsArticle';
import { Link } from 'react-router-dom';


function ListArticles() {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/produits').then((response) => setArticles(response.data));
  }, []);

  const deleteProd = async (id) => {
    if (!window.confirm('Are you sure you want to delete')) {
      return;
    }
    axios
      .delete('http://localhost:3001/produits/' + id)
      .then(() => {
        console.log('successfully deleted!');
        setArticles((prevArticles) => prevArticles.filter((article) => article.id !== id));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
    <br/>
      <center>
    
        <i>
        <h2 className="fw-bold mb-4">Liste des articles</h2>
        </i>
        <div className="nav-item" style={{ textAlign: 'left' }}>
  <Link
    className="nav-link btn"
    to="/addArticle"
    style={{
      backgroundColor: 'blue',
      color: '#FFFFFF',
      padding: '5px 15px',
      borderRadius: '3px',
      textDecoration: 'none',
      display: 'inline-block',
      textAlign: 'center',
      fontSize: '14px',
    }}
  >
    Add articles
  </Link>
</div>
<br/>
      </center>
      <div className="row row-cols-1 row-cols-md-4 g-4">
        {articles.map((article) => (
          <div className="col mb-4" key={article.id}>
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">{article.reference}</h3>
                <img src={article.imageartpetitf} className="card-img-top" alt={article.reference} />
                <p className="card-text">{article.designation}</p>
                <p className="card-text">{article.prixVente}Dt </p>
                <div>
                  <Link exact to={`/EditArticle/${article.id}`} className="btn btn-success me-2">
                    Modifier
                  </Link>
                  <button className="btn btn-danger" onClick={() => deleteProd(article.id)}>
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

export default ListArticles;
