import axios from "axios";
import { useEffect, useState } from "react";
import ElementsClient from "./ElementsClient";
import { Link } from 'react-router-dom';
function ListClient() {
  const [client, setClient] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:3001/client")
      .then((response) => setClient(response.data));
  }, []);

  const deleteProd = async (id) => {
    if (!window.confirm("Are you sure you want to delete")) {
      return;
    }

    axios
      .delete("http://localhost:3001/client/" + id)
      .then(() => {
        console.log("successfully deleted!");
        setClient((prevArticles) =>
          prevArticles.filter((client) => client.id !== id)
        );
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
        <>
        <center><h2>Liste des clients </h2></center>
        <div className="nav-item">
  <Link
    className="nav-link btn"
    to="/addClient"
    style={{
        backgroundColor: 'blue',
        color: '#FFFFFF',
        padding: '5px 15px',
        borderRadius: '3px',
        textDecoration: 'none',
        display: 'inline-block',
        textAlign: 'center',
        fontSize: '14px',
      }}
  >
    Add Client
  </Link>
</div>
        <ElementsClient client={client} deleteProd={deleteProd} />
        </>
     );
}

export default ListClient;
