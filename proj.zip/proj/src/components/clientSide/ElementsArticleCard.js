import { useShoppingCart } from 'use-shopping-cart';
import Button from '@mui/material/Button';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link } from 'react-router-dom';
import Grid from '@mui/material/Grid';

const ElementsArticleCard = (props) => {
  const { cartCount, addItem } = useShoppingCart();

  const addToCart = (product) => {
    const target = {
      id: product.id,
      title: product.designation,
      image: product.imageartpetitf,
      price: product.prixVente,
      qtestock: product.qtestock,
      quantity: 1,
    };
    addItem(target);
    console.log('Item added to cart:', target);
  };

  return (
    <>
      <AppBar position="static" color="default">
        <Toolbar>
          <Button color="inherit">
            <Link to="/cart">
              <ShoppingCartIcon fontSize="large" />
              <span style={{ marginLeft: '8px' }}>{cartCount}</span>
            </Link>
          </Button>
        </Toolbar>
      </AppBar>
      <Grid container spacing={2}>
        {props.articles &&
          props.articles.map((product) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={product.id}>
              <div className="card">
                <img
                  src={product.imageartpetitf}
                  className="card-img-top p-5"
                  alt={product.designation}
                />
                <div className="text-center">
                  <div>{product.designation.substr(0, 20)} ... </div>
                  <div>Prix : {product.prixVente} TND </div>
                </div>
                <br/>
                <div className="text-center">
                  <Button
                    disabled={product.qtestock <= 1}
                    variant="contained"
                    color="warning"
                    onClick={() => addToCart(product)}
                    style={{ marginTop: '8px' }}
                  >
                    <ShoppingCartIcon fontSize="large" />
                    <span style={{ marginLeft: '8px' }}>Add to Cart</span>
                  </Button>
                </div>
                <br/>
              </div>
            </Grid>
          ))}
      </Grid>
    </>
  );
};

export default ElementsArticleCard;
