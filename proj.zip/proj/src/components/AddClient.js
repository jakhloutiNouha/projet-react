import { useState } from "react";
import axios from "axios";
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";

function AddClient() {
  const navigate = useNavigate();
  const [id, setId] = useState("");
  const [Nom, setNom] = useState("");
  const [Prénom, setPrénom] = useState("");
  const [Email, setEmail] = useState("");
  const [Tel, setTel] = useState("");
  const [Adresse, setAdresse] = useState("");
  const [imageartpetitf, setImageartpetitf] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const newClient = {
      id: id,
      Nom,
      Prénom,
      Email,
      Tel,
      Adresse,
      imageartpetitf,
    };

    //faire le add dans la BD
    axios
      .post("http://localhost:3001/Client", newClient)
      .then((res) => {
        console.log(res);
        navigate("/AddClient");
      })
      .catch((error) => {
        console.log(error);
        alert("Erreur ! Insertion non effectuée");
      });
  };

  return (
    <div className="container">
      <h2>Ajout d'un Client </h2>
      <form onSubmit={handleSubmit}>
        <div className="grid gap-3">
          <div className="col-sm-5 p-2 g-col-6">
            <input
              className="form-control"
              placeholder="Nom"
              name="Nom"
              type="text"
              value={Nom}
              onChange={(e) => setNom(e.target.value)}
            />
          </div>
          <div className="col-sm-5 p-2 g-col-6">
            <input
              className="form-control"
              placeholder="Prénom"
              type="text"
              value={Prénom}
              onChange={(e) => setPrénom(e.target.value)}
            />
          </div>
          <div className="col-sm-5 p-2 g-col-6">
            <input
              className="form-control"
              placeholder="Email"
              type="email"
              value={Email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="col-sm-5 p-2 g-col-6">
            <input
              className="form-control"
              placeholder="Tel"
              type="number"
              value={Tel}
              onChange={(e) => setTel(e.target.value)}
            />
          </div>
          <div className="col-sm-5 p-2 g-col-6">
            <input
              className="form-control"
              placeholder="Adresse"
              type="text"
              value={Adresse}
              onChange={(e) => setAdresse(e.target.value)}
            />
          </div>
          <div className="col-sm-5 p-2 g-col-6">
            <input
              className="form-control"
              placeholder="Image"
              type="text"
              value={imageartpetitf}
              onChange={(e) => setImageartpetitf(e.target.value)}
            />
          </div>
          <div>
            {imageartpetitf ? (
              <img src={imageartpetitf} alt="" width="70" />
            ) : null}
          </div>
          <div>
            <button className="btn btn-success">Valider</button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default AddClient;