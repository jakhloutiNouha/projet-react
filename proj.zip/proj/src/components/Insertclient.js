import React from 'react';

export default function Insertclient() {
  return (
    <div>
      <h1> insert clients</h1>
    </div>
  );
}
